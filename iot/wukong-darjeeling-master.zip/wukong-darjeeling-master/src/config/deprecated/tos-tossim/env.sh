export NCC=/usr/bin/ncc
export PYTHON_LIBS=/usr/include/python2.5/
export TOSDIR=~/Programs/tinyos-2.1.0/tos/
