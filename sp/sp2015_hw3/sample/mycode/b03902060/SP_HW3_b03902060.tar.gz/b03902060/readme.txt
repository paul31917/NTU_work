1. Just use "make" to compile those programs.
   Use "make run" to run the priority type.
2. (1pt)Your bidding_system can deal with ordinary customers.
   (1pt)Your bidding_system can deal with ordinary customers and member cus-tomers.
   (1pt)Your bidding_system can deal with all types of customers. (ordinary, member, VIP)
   (2pt)You implement customer by yourself. You only need to implement customer based on priority scheduling .